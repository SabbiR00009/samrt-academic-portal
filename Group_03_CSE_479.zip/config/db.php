<?php
$conn = mysqli_connect("localhost", "root", "sabbir009", "smart_academic_portal");
if (!$conn) die("Connection failed: " . mysqli_connect_error());
?>